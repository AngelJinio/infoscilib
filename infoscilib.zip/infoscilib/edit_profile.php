<?php
include "config/config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'] ?? '';
    $username = $_POST['username'] ?? '';
    $email    = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($password)) {
        $hashed_pw = md5($password);
        $stmt = $conn->prepare("UPDATE users SET fullname=?, username=?, email=?, password=? WHERE id=?");
        $stmt->bind_param("ssssi", $fullname, $username, $email, $hashed_pw, $user_id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET fullname=?, username=?, email=? WHERE id=?");
        $stmt->bind_param("sssi", $fullname, $username, $email, $user_id);
    }

    if ($stmt->execute()) {
        $message = "Profile updated successfully!";
        $_SESSION['username'] = $username;
    } else {
        $message = "Error updating profile: " . $conn->error;
    }
}

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$display_name = $user['fullname'] ?? '';

include "includes/header.php";
?>

<div class="auth-page">
    <div class="form">
        <h2>Edit Profile</h2>
        <p style="text-align:center; color: #888; margin-bottom: 20px;">Update your account details</p>

        <?php if ($message): ?>
            <p style="color:green; text-align:center; font-weight:bold;"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="POST">
            <div style="text-align: left; margin-bottom: 15px;">
                <label>Full Name</label>
                <input type="text" name="fullname" value="<?= htmlspecialchars($display_name) ?>" required>
            </div>
            
            <div style="text-align: left; margin-bottom: 15px;">
                <label>Username</label>
                <input type="text" name="username" value="<?= htmlspecialchars($user['username'] ?? '') ?>" required>
            </div>
            
            <div style="text-align: left; margin-bottom: 15px;">
                <label>Email Address</label>
                <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
            </div>
            
            <div style="text-align: left; margin-bottom: 15px;">
                <label>New Password (leave blank to keep current)</label>
                <input type="password" name="password" placeholder="Enter new password">
            </div>

            <button type="submit" class="btn-yellow" style="width: 100%; border:none; cursor:pointer; font-weight:bold; padding: 10px;">Save Changes</button>
            <a href="dashboard.php" class="btn-gray" style="display:block; text-align:center; text-decoration:none; margin-top:10px; padding: 10px;">Back to Dashboard</a>
        </form>
    </div>
</div>

<?php include "includes/footer.php"; ?>