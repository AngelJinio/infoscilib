<?php include "config/config.php"; ?>
<?php include "includes/header.php"; ?>

<?php
$id = $_GET['id'];
$book = $conn->query("SELECT * FROM books WHERE id=$id")->fetch_assoc();
?>

<h2><?php echo $book['title']; ?></h2>
<p>Author: <?php echo $book['author']; ?></p>
<img src="assets/images/<?php echo $book['image']; ?>" class="book-img">

<?php include "includes/footer.php"; ?>
