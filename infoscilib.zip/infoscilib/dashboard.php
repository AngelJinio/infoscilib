<?php
include_once "config/config.php";
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$user_query = $conn->prepare("SELECT username, email, status, fullname FROM users WHERE id = ?");
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user = $user_query->get_result()->fetch_assoc();

$is_admin = (isset($user['status']) && $user['status'] === 'admin');

$recent_books = $conn->query("SELECT * FROM books ORDER BY id DESC LIMIT 5");
$book_total_res = $conn->query("SELECT COUNT(*) as total FROM books");
$book_total = ($book_total_res) ? $book_total_res->fetch_assoc()['total'] : 0;

include "includes/header.php"; 
?>

<div class="dashboard" style="max-width: 1200px; margin: 30px auto; padding: 20px;">
    <div class="dash-top" style="margin-bottom: 30px;">
        <h1 style="font-size: 2rem; color: #333;">Dashboard</h1>
        <p style="color: #666;">Welcome back, <strong><?= htmlspecialchars($user['username']) ?></strong>!</p>
    </div>

    <div class="dash-grid" style="display: grid; grid-template-columns: 1fr 2fr; gap: 25px;">
        
        <div class="dash-column">
            <div class="dash-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 20px;">
                <h3 style="border-bottom: 2px solid #f1c40f; padding-bottom: 10px; margin-bottom: 15px;">Account Details</h3>
                <div class="dash-info-list" style="line-height: 1.8;">
                    <p><strong>Full Name:</strong> <?= htmlspecialchars($user['fullname'] ?? 'Not Set') ?></p>
                    <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
                    <p><strong>Role:</strong> 
                        <span style="font-weight:bold; color: <?= $is_admin ? '#e74c3c' : '#2ecc71' ?>;">
                            <?= strtoupper(htmlspecialchars($user['status'])) ?>
                        </span>
                    </p>
                </div>
                
                <a href="edit_profile.php" class="btn-gray" style="display:block; text-align:center; text-decoration:none; margin-top: 20px; padding: 10px; border-radius: 5px; font-size: 14px;">Edit Profile</a>
            </div>

            <?php if ($is_admin): ?>
            <div class="dash-card" style="background: #fffdf0; border: 1px solid #f1c40f; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                <h3 style="color: #856404; margin-bottom: 15px;">Admin Controls</h3>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <a href="admin/add_book.php" class="btn-yellow" style="text-decoration:none; text-align:center; padding: 12px; border-radius: 5px; font-weight: bold;">+ Upload New Book</a>
                    <a href="admin/books.php" class="btn-gray" style="text-decoration:none; text-align:center; padding: 10px; border-radius: 5px;">Manage Library Inventory</a>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="dash-column">
            <div class="dash-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3 style="margin: 0;">Recent Library Additions</h3>
                    <span style="background: #eee; padding: 5px 12px; border-radius: 20px; font-size: 13px;">Total Books: <?= $book_total ?></span>
                </div>
                
                <ul style="list-style: none; padding: 0;">
                    <?php if ($recent_books->num_rows > 0): ?>
                        <?php while($book = $recent_books->fetch_assoc()): ?>
                            <li style="padding: 15px; border-bottom: 1px solid #f5f5f5; display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <strong style="color: #333;"><?= htmlspecialchars($book['title']) ?></strong><br>
                                    <small style="color: #888;">By <?= htmlspecialchars($book['author']) ?> | <?= htmlspecialchars($book['category']) ?></small>
                                </div>
                                
                                <div style="display: flex; gap: 8px;">
                                    <a href="book_details.php?id=<?= $book['id'] ?>" class="btn-view" style="font-size: 12px; padding: 6px 12px; background: #3498db; color: white; text-decoration: none; border-radius: 4px;">View</a>
                                    
                                        <?php if ($is_admin): ?>
                                        <a href="admin/edit_book.php?id=<?= $book['id'] ?>" class="btn-edit" style="font-size: 12px; padding: 6px 12px; background: #f1c40f; color: black; text-decoration: none; border-radius: 4px;">Edit</a>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="text-align: center; color: #999; padding: 20px;">No books available in the library yet.</p>
                    <?php endif; ?>
                </ul>
                
                <div style="margin-top: 20px; text-align: center;">
                    <a href="books.php" style="color: #3498db; text-decoration: none; font-weight: bold;">Browse Full Library →</a>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include "includes/footer.php"; ?>