<?php
require_once "config/config.php"; 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['name']); 
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $check->bind_param("ss", $username, $email);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $error = "Username or Email already taken.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, fullname, status) VALUES (?, ?, ?, ?, 'user')");
        $stmt->bind_param("ssss", $username, $email, $hashed_password, $username);

        if ($stmt->execute()) {
            header("Location: login.php?signup=success");
            exit;
        }
    }
}
?>

<?php include "includes/header.php"; ?>

<div class="auth-page">
    <form method="post" class="form">
        <h2>Create Account</h2>
        <input type="text" name="name" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Sign Up</button>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </form>
</div>

<?php include "includes/footer.php"; ?>