<?php
include_once "config/config.php";
include "includes/header.php";

// 1. Get the book ID from the URL
$id = $_GET['id'] ?? null;

if (!$id) {
    echo "<script>window.location.href='books.php';</script>";
    exit;
}

// 2. Fetch specific book details
$stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$book = $stmt->get_result()->fetch_assoc();

if (!$book) {
    die("<div class='info'><h3>Book not found.</h3><a href='books.php' class='btn'>Back to Library</a></div>");
}
$cat = $book['category'];
$related_stmt = $conn->prepare("SELECT * FROM books WHERE category = ? AND id != ? LIMIT 3");
$related_stmt->bind_param("si", $cat, $id);
$related_stmt->execute();
$related_result = $related_stmt->get_result();
?>

<div class="details-wrapper" style="max-width: 1100px; margin: 40px auto; padding: 0 20px;">
    
    <div class="dash-card" style="display: flex; gap: 40px; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); align-items: flex-start;">
        
        <div style="flex: 0 0 320px;">
            <img src="assets/images/books/<?= htmlspecialchars($book['image']) ?>" 
                 alt="<?= htmlspecialchars($book['title']) ?>" 
                 style="width: 100%; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
        </div>

        <div style="flex: 1;">
            <h1 style="margin: 0 0 10px 0; font-size: 32px; color: #1a1a1a;"><?= htmlspecialchars($book['title']) ?></h1>
            <h4 style="margin: 0 0 20px 0; color: #666; font-weight: 500;">By <?= htmlspecialchars($book['author']) ?></h4>
            
            <p style="line-height: 1.8; color: #444; margin-bottom: 25px;">
                <?= nl2br(htmlspecialchars($book['description'])) ?>
            </p>

            <div style="background: #f9f9f9; padding: 15px; border-radius: 6px; margin-bottom: 30px;">
                <p style="margin: 5px 0;"><strong>Category:</strong> <?= htmlspecialchars($book['category']) ?></p>
                <p style="margin: 5px 0;"><strong>Field:</strong> <?= htmlspecialchars($book['field']) ?></p>
            </div>

            <div class="action-area">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if (!empty($book['file_path'])): ?>
                        <a href="assets/files/<?= $book['file_path'] ?>" download class="btn-yellow" 
                           style="text-decoration:none; padding: 15px 40px; font-size: 16px; border-radius: 5px; display: inline-block;">
                           Read / Download Book
                        </a>
                    <?php else: ?>
                        <button disabled class="btn-gray" style="padding: 15px 40px; border-radius: 5px;">File Currently Unavailable</button>
                    <?php endif; ?>

                <?php else: ?>
                    <div style="border: 1px dashed #f1c40f; padding: 20px; border-radius: 8px; background: #fffdf0;">
                        <p style="margin: 0 0 10px 0; font-weight: bold; color: #856404;">Access Restricted</p>
                        <p style="margin: 0 0 15px 0; font-size: 14px; color: #666;">You must have an account to read or download this resource.</p>
                        <a href="login.php" class="btn-yellow" style="text-decoration:none; padding: 10px 25px; border-radius: 4px; display: inline-block;">
                            Login to Download
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div style="margin-top: 50px;">
        <h3 style="border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 25px;">Related Books</h3>
        <div class="grid">
            <?php if ($related_result->num_rows > 0): ?>
                <?php while($rel = $related_result->fetch_assoc()): ?>
                    <div class="card" style="transition: transform 0.2s;">
                        <a href="book_details.php?id=<?= $rel['id'] ?>" style="text-decoration: none; color: inherit;">
                            <img src="assets/images/books/<?= htmlspecialchars($rel['image']) ?>" alt="">
                            <h4 style="margin: 12px 0 5px;"><?= htmlspecialchars($rel['title']) ?></h4>
                            <p style="font-size: 13px; color: #777;"><?= htmlspecialchars($rel['author']) ?></p>
                        </a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #999;">No related books found in this category.</p>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php include "includes/footer.php"; ?>