<?php
include_once __DIR__ . '/../config/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['status'] !== 'admin') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: books.php"); exit; }

$stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$book = $stmt->get_result()->fetch_assoc();

if (!$book) { die("Book not found."); }

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $category = $_POST['category'];
    $field = $_POST['field'];
    $description = $_POST['description'];

    if (!empty($_FILES['cover']['name'])) {
        $imageName = time() . "_" . $_FILES['cover']['name'];
        $target = "../assets/images/books/" . $imageName;

        if (move_uploaded_file($_FILES['cover']['tmp_name'], $target)) {
            if (file_exists("../assets/images/books/" . $book['image'])) {
                @unlink("../assets/images/books/" . $book['image']);
            }
            $updateStmt = $conn->prepare("UPDATE books SET title=?, author=?, category=?, field=?, description=?, image=? WHERE id=?");
            $updateStmt->bind_param("ssssssi", $title, $author, $category, $field, $description, $imageName, $id);
        }
    } else {
        $updateStmt = $conn->prepare("UPDATE books SET title=?, author=?, category=?, field=?, description=? WHERE id=?");
        $updateStmt->bind_param("sssssi", $title, $author, $category, $field, $description, $id);
    }

    if ($updateStmt->execute()) {
        header("Location: books.php?status=updated"); 
        exit;
    } else {
        $message = "Error updating: " . $conn->error;
    }
}

include "../includes/header.php";
?>

<div class="admin-container">
    <div class="admin-card">
        <h2>Admin - Edit Book Details</h2>
        <div class="admin-meta"><p>Book ID: <?= $id ?></p></div>

        <form method="POST" enctype="multipart/form-data">
            <div class="admin-form-group">
                <label>Title</label>
                <input type="text" name="title" value="<?= htmlspecialchars($book['title']) ?>" required>
                <label>Field</label>
                <input type="text" name="field" value="<?= htmlspecialchars($book['field']) ?>">
                
                <label>Author</label>
                <input type="text" name="author" value="<?= htmlspecialchars($book['author']) ?>" required>
                <label>Category</label>
                <input type="text" name="category" value="<?= htmlspecialchars($book['category']) ?>">
                
                <label>Description</label>
                <input type="text" name="description" value="<?= htmlspecialchars($book['description']) ?>" style="grid-column: span 3;">
            </div>

            <p style="margin-top:20px; font-weight:bold;">Update Cover Image (Leave blank to keep current)</p>
            <div class="image-section">
                <div class="preview-box">
                    <img src="<?= BASE_URL ?>assets/images/books/<?= $book['image'] ?>" alt="Current">
                </div>
                <div>
                    <input type="file" name="cover">
                    <p class="muted">Current File: <?= $book['image'] ?></p>
                </div>
            </div>

            <div class="btn-group">
                <button type="submit" class="btn-yellow">Save Changes</button>
                <a href="books.php" class="btn-gray" style="text-decoration:none;">Cancel</a>
            </div>
            <?php if($message) echo "<p style='color:red;'>$message</p>"; ?>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>