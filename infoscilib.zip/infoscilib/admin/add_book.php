<?php
include_once __DIR__ . '/../config/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['status'] !== 'admin') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $category = $_POST['category'];
    $field = $_POST['field'];
    $description = $_POST['description'];

    $imageName = "";
    if (!empty($_FILES['cover']['name'])) {
        $imageName = time() . "_" . $_FILES['cover']['name'];
        move_uploaded_file($_FILES['cover']['tmp_name'], "../assets/images/books/" . $imageName);
    }

    $fileName = "";
    if (!empty($_FILES['book_file']['name'])) {
        $fileName = time() . "_" . $_FILES['book_file']['name'];
        $fileDir = "../assets/files/";
        if (!is_dir($fileDir)) mkdir($fileDir, 0777, true);
        move_uploaded_file($_FILES['book_file']['tmp_name'], $fileDir . $fileName);
    }

    $stmt = $conn->prepare("INSERT INTO books (title, author, category, field, image, file_path, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $title, $author, $category, $field, $imageName, $fileName, $description);
    
    if($stmt->execute()) {
        $message = "Book and File uploaded successfully!";
    }
}
include "../includes/header.php";
?>

<div class="admin-container">
    <div class="admin-card">
        <h2>Admin - Upload New Book</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="admin-form-group">
                <label>Title</label><input type="text" name="title" required>
                <label>Field</label><input type="text" name="field">
                <label>Author</label><input type="text" name="author" required>
                <label>Category</label><input type="text" name="category">
                <label>Description</label><textarea name="description" style="grid-column: span 3;"></textarea>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                <div>
                    <label>Book Cover Image</label>
                    <input type="file" name="cover" accept="image/*" required>
                </div>
                <div>
                    <label>Book Document (PDF, DOCX, PPT)</label>
                    <input type="file" name="book_file" required>
                </div>
            </div>

            <div class="btn-group" style="margin-top:20px;">
                <button type="submit" class="btn-yellow">Upload Everything</button>
            </div>
            <p><?= $message ?></p>
        </form>
    </div>
</div>
<?php include "../includes/footer.php"; ?>