<?php
include "../config/config.php";
include "../includes/auth.php";
include "../includes/header.php";

$result = $conn->query("SELECT name, username, status FROM users");
?>

<h2>All Users</h2>

<table border="1" cellpadding="10">
<tr>
  <th>Name</th>
  <th>Username</th>
  <th>Status</th>
</tr>

<?php while($u = $result->fetch_assoc()): ?>
<tr>
  <td><?= $u['name'] ?></td>
  <td><?= $u['username'] ?></td>
  <td><?= ucfirst($u['status']) ?></td>
</tr>
<?php endwhile; ?>
</table>

<?php include "../includes/footer.php"; ?>
