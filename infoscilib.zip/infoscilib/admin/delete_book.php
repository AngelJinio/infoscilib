<?php
include_once __DIR__ . '/../config/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['status'] !== 'admin') {
    header("Location: " . BASE_URL . "index.php");
    exit;
}

$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: books.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$book = $stmt->get_result()->fetch_assoc();

if (!$book) {
    die("Book not found.");
}

if (isset($_POST['confirm_delete'])) {

    $imagePath = "../assets/images/books/" . $book['image'];
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }

    $deleteStmt = $conn->prepare("DELETE FROM books WHERE id = ?");
    $deleteStmt->bind_param("i", $id);
    
    if ($deleteStmt->execute()) {
        header("Location: books.php?message=deleted");
        exit;
    }
}

include "../includes/header.php";
?>

<div class="admin-container">
    <div class="admin-card">
        <h2>Admin - Delete Book</h2>
        <div class="admin-meta">
            <p>Book ID: <?= htmlspecialchars($id) ?></p>
            <p>Status: Admin</p>
        </div>

        <div class="image-section" style="margin-bottom:30px; display: flex; align-items: center; gap: 20px;">
            <div class="preview-box" style="width:120px; height:160px; overflow: hidden; border: 1px solid #ddd;">
                <img src="<?= BASE_URL ?>assets/images/books/<?= $book['image'] ?>" alt="Cover" style="width:100%; height:100%; object-fit: cover;">
            </div>
            <div>
                <h3 style="margin: 0;"><?= htmlspecialchars($book['title']) ?></h3>
                <p style="color: #666;">By <?= htmlspecialchars($book['author']) ?></p>
            </div>
        </div>

        <div style="text-align:center; padding: 20px; background: #fff5f5; border-radius: 8px;">
            <h3 style="color: #e74c3c; margin-bottom:10px;">Are you sure you want to delete this book?</h3>
            <p>This action is permanent and will remove the file from the server.</p>
        </div>

        <form method="POST" class="btn-group">
            <button type="submit" name="confirm_delete" class="btn-red" style="width:200px;">Confirm Delete</button>
            <a href="books.php" class="btn-gray" style="text-decoration:none; display:inline-block; padding:10px 40px;">Cancel</a>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>