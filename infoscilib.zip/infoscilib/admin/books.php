<?php
include_once __DIR__ . '/../config/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['status'] !== 'admin') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$result = $conn->query("SELECT * FROM books ORDER BY id DESC");
?>

<?php include "../includes/header.php"; ?>

<div class="admin-container">
    <div class="admin-card" style="max-width: 1000px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h2>Admin - Manage Library</h2>
                <p class="admin-meta">Total Books: <?= $result->num_rows ?></p>
            </div>
            <a href="add_book.php" class="btn-yellow" style="text-decoration: none;">+ Upload New Book</a>
        </div>

        <div class="grid">
            <?php while ($book = $result->fetch_assoc()): ?>
                <div class="card" style="border: 1px solid #eee; padding:10px;">
                    <div style="height: 200px; overflow:hidden;">
                        <img src="<?= BASE_URL ?>assets/images/books/<?= $book['image'] ?>" style="width:100%; height:100%; object-fit:cover;">
                    </div>
                    <h4><?= htmlspecialchars($book['title']) ?></h4>
                    <p>By <?= htmlspecialchars($book['author']) ?></p>
                    <div style="display:flex; gap:5px; margin-top:10px;">
                        <a href="edit_book.php?id=<?= $book['id'] ?>" class="btn-yellow" style="flex:1; text-align:center; text-decoration:none; font-size:12px; padding:5px;">Edit</a>
                        <a href="delete_book.php?id=<?= $book['id'] ?>" class="btn-red" style="flex:1; text-align:center; text-decoration:none; font-size:12px; padding:5px;">Delete</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<?php include "../includes/footer.php"; ?>