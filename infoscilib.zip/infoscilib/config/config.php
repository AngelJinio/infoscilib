<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_URL', '/infoscilib/');

$conn = new mysqli("localhost", "root", "", "darahlib");

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>