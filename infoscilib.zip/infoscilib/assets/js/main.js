document.addEventListener("DOMContentLoaded", () => {
    console.log("DarahLib loaded successfully");
});
