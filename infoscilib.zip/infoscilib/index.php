<?php include "config/config.php"; ?>
<?php include "includes/header.php"; ?>

<div class="hero">
    <div class="hero-overlay">
        <h2>Welcome to InfoSci Library</h2>
        <p>InfoSci Library is a modern digital library system designed to provide
            students and readers easy access to books, learning resources,
            and knowledge anytime, anywhere.
        </p>
        <a href="books.php" class="btn">Explore Books</a>
    </div>
</div>

<section class="info" style="border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
    <div style="max-width: 1000px; margin: 0 auto; text-align: left;">
        <h3 style="text-align: center; font-size: 28px; margin-bottom: 20px;">About InfoSci Library</h3>
        
        <p style="line-height: 1.8; color: #444; margin-bottom: 30px;">
            <strong>InfoSci Library</strong> is a modern, comprehensive digital repository designed to bridge the gap between traditional academic resources and the evolving needs of the 21st-century learner. Originally conceptualized as a physical collection, InfoSci Library has transitioned into a robust <strong>Digital Resource Management System</strong> that empowers students and educators by providing instant, 24/7 access to a diverse array of knowledge.
        </p>

        <div class="dash-grid" style="grid-template-columns: 1fr 1fr; gap: 30px; background: transparent;">
            <div style="background: #f9f9f9; padding: 20px; border-left: 5px solid #ffcc00; border-radius: 4px;">
                <h4 style="margin-top: 0;">Our Mission</h4>
                <p style="font-size: 14px; color: #666; line-height: 1.6;">
                    To democratize education by making high-quality academic materials—ranging from traditional fiction to specialized reference guides—available at the click of a button.
                </p>
            </div>
            <div style="background: #f9f9f9; padding: 20px; border-left: 5px solid #1a1a1a; border-radius: 4px;">
                <h4 style="margin-top: 0;">What We Offer</h4>
                <ul style="font-size: 14px; color: #666; padding-left: 15px; margin: 0;">
                    <li>Diverse Digital Collection</li>
                    <li>PDF, DOCX, & PPT Downloads</li>
                    <li>Unified Student Dashboard</li>
                </ul>
            </div>
        </div>

        <div style="margin-top: 40px; padding: 20px; background: #1a1a1a; color: white; border-radius: 8px; text-align: center;">
            <h4 style="color: #ffcc00; margin-top: 0;">Innovation Through Technology</h4>
            <p style="font-size: 15px; opacity: 0.9; line-height: 1.6;">
                Built on a secure and scalable architecture, InfoSci Library utilizes advanced database management to ensure data integrity and user security for a community of continuous learning.
            </p>
        </div>
    </div>
</section>

<?php include "includes/footer.php"; ?>