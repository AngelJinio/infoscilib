<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>InfoSci Library</title>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css"></head>
<body>

<?php include_once __DIR__ . '/../config/config.php'; ?>

<header class="header">
    <div class="nav-container">
        <div class="logo">InfoSci Library</div>

        <nav class="nav">
            <a href="<?= BASE_URL ?>index.php">Home</a>
            <a href="<?= BASE_URL ?>books.php">Books</a>

            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?= BASE_URL ?>dashboard.php">Dashboard</a>
                <a href="<?= BASE_URL ?>logout.php">Logout</a>
            <?php else: ?>
                <a href="<?= BASE_URL ?>login.php">Login</a>
                <a href="<?= BASE_URL ?>signup.php">Signup</a>
            <?php endif; ?>
        </nav>
    </div>
</header>



<main>
