</main> <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h2 class="logo" style="font-size: 20px; margin: 0 0 5px 0;">InfoSci Library</h2>
            <p>Advanced digital library management system for seamless book access and operations.</p>
        </div>

        <div class="footer-section">
            <h3>Contact</h3>
            <ul style="list-style: none; padding: 0;">
                <li>✉️ info@infoscilab.org</li>
                <li>📞 +254 700 000 000</li>
                <li>🌐 InfoSci LibraryCreations</li>
            </ul>
        </div>

        <div class="footer-section">
            <h3>Links</h3>
            <ul style="list-style: none; padding: 0;">
                <li><a href="index.php" style="color: #bbb; text-decoration: none;">Home</a></li>
                <li><a href="books.php" style="color: #bbb; text-decoration: none;">Books</a></li>
                <li><a href="login.php" style="color: #bbb; text-decoration: none;">Login</a></li>
            </ul>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>© 2026 InfoSci Library Creations. All Rights Reserved.</p>
    </div>
</footer>