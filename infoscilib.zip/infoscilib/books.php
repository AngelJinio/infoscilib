<?php 
include_once __DIR__ . "/config/config.php"; 
include "includes/header.php"; 

$cat_result = $conn->query("SELECT DISTINCT category FROM books WHERE category != ''");
$selected_cats = isset($_GET['categories']) ? $_GET['categories'] : [];
$search_q = $_GET['q'] ?? '';
?>

<div class="books-layout">
    <aside class="filters">
        <h4>Filter By</h4>
        <p>Book Category</p>
        
        <form id="filterForm" method="GET" action="books.php">
            <input type="hidden" name="q" value="<?= htmlspecialchars($search_q) ?>">
            
            <?php while($cat = $cat_result->fetch_assoc()): 
                $cat_name = $cat['category'];
                $checked = in_array($cat_name, $selected_cats) ? 'checked' : '';
            ?>
                <label>
                    <input type="checkbox" name="categories[]" value="<?= htmlspecialchars($cat_name) ?>" 
                           onchange="this.form.submit()" <?= $checked ?>> 
                    <?= htmlspecialchars($cat_name) ?>
                </label><br>
            <?php endwhile; ?>

            <br>
            <a href="books.php" class="btn" style="text-decoration:none; display:inline-block; text-align:center;">Clear All</a>
        </form>
    </aside>

    <section class="books-content">
        <div class="books-header">
            <h2>Library Collection</h2>
            <form method="get" class="search-bar">
                <label>Search</label>
                <input type="text" name="q" placeholder="Enter book name" value="<?= htmlspecialchars($search_q) ?>">
            </form>
        </div>

        <div class="grid">
            <?php
            $conditions = [];
            $params = [];
            $types = "";

            if (!empty($search_q)) {
                $conditions[] = "title LIKE ?";
                $params[] = "%$search_q%";
                $types .= "s";
            }
            if (!empty($selected_cats)) {
                $placeholders = implode(',', array_fill(0, count($selected_cats), '?'));
                $conditions[] = "category IN ($placeholders)";
                foreach ($selected_cats as $cat) {
                    $params[] = $cat;
                    $types .= "s";
                }
            }

            $sql = "SELECT * FROM books";
            if (!empty($conditions)) {
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }
            $sql .= " ORDER BY id DESC";

            $stmt = $conn->prepare($sql);
            
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 0) {
                echo "<p><strong>No books found matching these filters.</strong></p>";
            }

            while ($row = $result->fetch_assoc()):
            ?>
                <div class="card">
                    <img src="assets/images/books/<?= htmlspecialchars($row['image']) ?>" alt="">
                    <h4><?= htmlspecialchars($row['title']) ?></h4>
                    <p><?= htmlspecialchars($row['author']) ?></p>
                    <a href="book_details.php?id=<?= $row['id'] ?>" class="btn">View Details</a>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
</div>

<?php include "includes/footer.php"; ?>