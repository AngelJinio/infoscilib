<?php
include "config/config.php";

if (isset($_POST['login_btn'])) {
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);

    // We select specific columns to ensure they exist
    $stmt = $conn->prepare("SELECT id, username, email, password, status FROM users WHERE email = ? OR username = ?");
    $stmt->bind_param("ss", $login, $login); 
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        // Verify the hashed password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['status'] = $user['status'];
            $_SESSION['username'] = $user['username'];
            
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "No account found with that username/email.";
    }
}
?>

<?php include "includes/header.php"; ?>

<div class="auth-page">
    <form method="post" class="form">
        <h2>Login</h2>

        <input type="text" name="login" placeholder="Username or Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login_btn">Login</button>

        <?php if (isset($error)) echo "<p style='color:red;text-align:center'>$error</p>"; ?>
    </form>
</div>

<?php include "includes/footer.php"; ?>
