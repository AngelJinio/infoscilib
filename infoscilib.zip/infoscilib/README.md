## DaraLibrary

## Project Overview
DarahLib is a PHP–MySQL library web application developed for academic submission.
It provides user authentication (signup/login) and basic library browsing features.

- PHP (procedural)
- MySQL (XAMPP)
- HTML/CSS/JS


1. Copy folder to C:\xampp\htdocs\DarahLib
2. Start Apache & MySQL
3. Import sql/darahlib.sql via phpMyAdmin
4. Visit http://localhost/darahlibrary

## Accounts

Admin: admin
password: admin

student account: demo@gmail.com/demo
password: demo
