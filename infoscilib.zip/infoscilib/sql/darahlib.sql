CREATE DATABASE IF NOT EXISTS darahlib;
USE darahlib;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE, 
    fullname VARCHAR(100),                
    email VARCHAR(100) NOT NULL UNIQUE,   
    password VARCHAR(255) NOT NULL,       
    status VARCHAR(20) DEFAULT 'user'    
);

CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    author VARCHAR(100) NOT NULL,
    description TEXT,                     
    category VARCHAR(50),                 
    field VARCHAR(50),                    
    image VARCHAR(150),                   
    file_path VARCHAR(255)               
);

INSERT INTO books (title, author, description, category, field, image, file_path) VALUES
('The Chronicles Eldoria', 'Elara Vance', 'An epic adventure through the mystical realms of Eldoria.', 'Fiction', 'Literature', 'eldoria.jpg', 'eldoria.pdf'),
('Introduction to Programming', 'John Smith', 'Learn the fundamentals of modern software development.', 'Education', 'Computer Science', 'book1.jpg', 'intro_prog.pdf'),
('Web Development Basics', 'Jane Doe', 'A guide to HTML, CSS, and JavaScript for beginners.', 'Education', 'Web Design', 'book2.jpg', 'web_basics.pdf'),
('Database Systems', 'Alan Turing', 'In-depth exploration of SQL and relational database management.', 'Reference', 'Data Science', 'book3.jpg', 'db_systems.pdf');

INSERT INTO users (username, fullname, email, password, status) 
VALUES ('admin', 'System Administrator', 'admin@infoscilib.org', '$2y$10$Pg5itycYg89T4L1dDx1ADuzPJWKVCWpseLiKSRoPlCfKiyGDQzc4K', 'admin');
