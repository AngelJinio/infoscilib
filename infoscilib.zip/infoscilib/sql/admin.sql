
INSERT INTO users (name, username, email, password, status)
VALUES (
    'DaraLib Admin',
    'admin',
    'daralib@gmail.com',
    '$$2y$10$Pg5itycYg89T4L1dDx1ADuzPJWKVCWpseLiKSRoPlCfKiyGDQzc4K',
    'admin'
);
